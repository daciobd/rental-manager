const express = require('express');
const path = require('path');
const app = express();

// Porta do Render (variável de ambiente) ou porta local
const PORT = process.env.PORT || 3000;

// Servir arquivos estáticos (HTML, CSS, JS, imagens, etc)
app.use(express.static(__dirname));

// Rota principal - serve o index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando na porta ${PORT}`);
  console.log(`📱 Acesse: http://localhost:${PORT}`);
});
