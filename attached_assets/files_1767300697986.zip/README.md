# 🏠 Sistema de Gestão de Aluguéis

Sistema completo para gerenciar imóveis, contratos, recebimentos e cálculos de impostos.

## 🚀 Deploy no Render - Passo a Passo

### **Pré-requisitos**
- Conta no GitHub (gratuita)
- Conta no Render (gratuita)

---

## 📋 PASSO 1: Preparar no Replit

✅ Você já está aqui! Os arquivos estão prontos:
- `index.html` - Seu sistema
- `server.js` - Servidor web
- `package.json` - Configurações

---

## 📤 PASSO 2: Enviar para o GitHub

### 2.1 - Criar Repositório no GitHub

1. Acesse: https://github.com
2. Clique em **"New repository"** (botão verde)
3. Preencha:
   - **Repository name**: `gestao-alugueis`
   - **Description**: Sistema de Gestão de Aluguéis
   - Marque: ✅ **Public**
   - NÃO marque "Add a README file"
4. Clique em **"Create repository"**

### 2.2 - Conectar Replit ao GitHub

**No Replit:**

1. Abra o **Shell** (terminal) no Replit
2. Execute estes comandos **um por vez**:

```bash
# Configurar Git (use seu email e nome do GitHub)
git config --global user.email "seu-email@example.com"
git config --global user.name "Seu Nome"

# Inicializar repositório
git init

# Adicionar todos os arquivos
git add .

# Fazer commit
git commit -m "Primeira versão do sistema de gestão de aluguéis"

# Adicionar repositório remoto (SUBSTITUA 'seu-usuario' pelo seu username do GitHub)
git remote add origin https://github.com/seu-usuario/gestao-alugueis.git

# Enviar para GitHub
git branch -M main
git push -u origin main
```

**⚠️ Atenção:**
- O GitHub vai pedir **username** e **senha**
- **NÃO use sua senha normal!** Use um **Personal Access Token**

### 2.3 - Criar Token do GitHub (se necessário)

1. GitHub → Settings → Developer settings
2. Personal access tokens → Tokens (classic)
3. Generate new token (classic)
4. Marque: `repo` (todos os sub-itens)
5. Generate token
6. **COPIE O TOKEN** (só aparece uma vez!)
7. Use como senha no git push

---

## 🌐 PASSO 3: Deploy no Render

### 3.1 - Criar Conta no Render

1. Acesse: https://render.com
2. Clique em **"Get Started"**
3. Faça login com GitHub (mais fácil!)

### 3.2 - Criar Web Service

1. No dashboard do Render, clique em **"New +"**
2. Selecione **"Web Service"**
3. Clique em **"Connect a repository"**
4. Autorize o Render a acessar seus repositórios
5. Selecione: **gestao-alugueis**

### 3.3 - Configurar Deploy

Preencha os campos:

- **Name**: `gestao-alugueis` (ou qualquer nome único)
- **Region**: `Oregon (US West)` (mais rápido para Brasil)
- **Branch**: `main`
- **Root Directory**: (deixe vazio)
- **Runtime**: `Node`
- **Build Command**: `npm install`
- **Start Command**: `npm start`
- **Instance Type**: `Free`

### 3.4 - Finalizar

1. Clique em **"Create Web Service"**
2. Aguarde 2-5 minutos (o Render vai instalar e iniciar)
3. Quando aparecer **"Live"** em verde, está pronto! 🎉

### 3.5 - Acessar seu Site

Seu site estará disponível em:
```
https://gestao-alugueis-XXXX.onrender.com
```

(O XXXX será gerado automaticamente)

---

## 🔄 Atualizações Futuras

Quando quiser atualizar o sistema:

**No Replit:**
```bash
git add .
git commit -m "Descrição da atualização"
git push
```

O Render detecta automaticamente e atualiza seu site! ✨

---

## ⚠️ Observações Importantes

### Plano Gratuito do Render:
- ✅ Hospedagem gratuita permanente
- ⚠️ Site "dorme" após 15 min sem uso
- ⏰ Primeiro acesso após dormir: ~30 segundos para acordar
- 💾 Dados salvos no navegador (localStorage)

### Alternativas Mais Rápidas (sem dormir):
- **Vercel**: https://vercel.com (deploy instantâneo)
- **Netlify**: https://netlify.com (drag & drop)
- **GitHub Pages**: Gratuito, sempre ativo

---

## 🆘 Problemas Comuns

### "Permission denied" no git push
→ Use Personal Access Token em vez de senha

### "Repository not found"
→ Verifique se o URL do GitHub está correto

### Site não carrega no Render
→ Confira se marcou "Node" como Runtime
→ Verifique se os comandos build/start estão corretos

### Dados desaparecem
→ Normal! localStorage salva no navegador
→ Use backup exportando os dados regularmente

---

## 📞 Precisa de Ajuda?

Volte aqui e me diga onde travou! Vou te ajudar a resolver. 🚀

---

## 🎯 Próximos Passos

Depois do deploy funcionando, podemos:
- ✨ Adicionar edição/exclusão de dados
- 📊 Criar gráficos e relatórios
- 📧 Sistema de backup automático
- 🔔 Notificações de vencimento
- 📱 Melhorar responsividade mobile

**Sucesso!** 🎉
