# 🌱 COMO USAR O SEED

## 📋 O QUE O SEED VAI CRIAR:

### 👤 **1 Usuário Admin:**
- Email: `admin@gestao.com`
- Senha: `admin123`

### 🏠 **5 Imóveis:**
1. Apartamento no Jardim Paulista - R$ 2.500/mês
2. Casa na Bela Vista - R$ 3.500/mês
3. Loja Comercial no Centro - R$ 5.000/mês
4. Apartamento na Consolação - R$ 3.200/mês
5. Sala Comercial na República - R$ 4.200/mês

### 📄 **5 Contratos Ativos:**
- Com inquilinos variados (PF e PJ)
- Datas de vencimento diferentes
- Emails e telefones

### 💰 **15 Pagamentos:**
- **Janeiro/2024**: 4 pagos
- **Fevereiro/2024**: 4 pagos, 1 atrasado, 1 pendente
- **Março/2024**: 1 pago, 4 pendentes

---

## 🚀 COMO EXECUTAR:

### **Opção 1: Adicionar ao código (RECOMENDADO)**

#### Passo 1: Copiar arquivo seed.ts

No Replit, crie o arquivo `server/seed.ts` com o conteúdo do arquivo que disponibilizei.

#### Passo 2: Atualizar server/index.ts

Abra `server/index.ts` e adicione:

**NO TOPO** (depois dos imports):
```typescript
import { seedDatabase } from './seed';
```

**DEPOIS de `await runMigrations();`**:
```typescript
// Executar seed (apenas em desenvolvimento ou primeira vez)
if (process.env.SEED_DATABASE === 'true') {
  await seedDatabase();
}
```

#### Passo 3: Fazer deploy com seed

No Render:
1. Vá em **Environment**
2. Adicione variável temporária:
   - **Key**: `SEED_DATABASE`
   - **Value**: `true`
3. Salve e aguarde deploy
4. **IMPORTANTE**: Depois que funcionar, **DELETE** a variável `SEED_DATABASE` para não executar sempre!

---

### **Opção 2: Script separado (MAIS SEGURO)**

#### Passo 1: Criar arquivo

No Replit, crie `scripts/seed.ts`:

```typescript
import { seedDatabase } from '../server/seed';
import { pool } from '../server/db';

async function main() {
  try {
    await seedDatabase();
    await pool.end();
    process.exit(0);
  } catch (error) {
    console.error('Erro:', error);
    process.exit(1);
  }
}

main();
```

#### Passo 2: Adicionar script no package.json

```json
{
  "scripts": {
    "seed": "tsx scripts/seed.ts"
  }
}
```

#### Passo 3: Executar localmente

No Replit:
```bash
npm run seed
```

---

## ⚠️ IMPORTANTE:

### **O seed verifica se já existem dados!**

Se já existir algum usuário no banco, ele **NÃO vai executar** novamente.

Para resetar e executar de novo:

```sql
-- CUIDADO: Isso apaga TODOS os dados!
DELETE FROM payments;
DELETE FROM contracts;
DELETE FROM properties;
DELETE FROM users;
```

---

## 📊 RESULTADO ESPERADO:

Depois do seed, você verá no log:

```
🌱 Iniciando seed do banco de dados...
✅ Usuário admin criado
✅ 5 imóveis criados
✅ 5 contratos criados
✅ 15 pagamentos criados
🎉 Seed concluído com sucesso!

📊 Resumo dos dados criados:
   👤 1 usuário (admin@gestao.com / admin123)
   🏠 5 imóveis
   📄 5 contratos
   💰 15 pagamentos

✅ Você já pode fazer login e ver o sistema populado!
```

---

## 🎯 QUAL OPÇÃO USAR?

**Opção 1** - Se quer demonstração rápida no Render  
**Opção 2** - Se quer testar localmente primeiro

---

## 🆘 PRECISA DE AJUDA?

Me diga qual opção você quer usar e eu te guio! 🚀
