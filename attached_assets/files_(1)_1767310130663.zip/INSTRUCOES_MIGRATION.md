# 🔧 CORREÇÃO: Criar Tabelas Automaticamente

## 📋 INSTRUÇÕES PASSO A PASSO

### Passo 1: Criar arquivo de migrations

No Replit, execute:

```bash
cd /home/runner/workspace
```

Crie um novo arquivo chamado `server/migrate.ts` com o seguinte conteúdo:

```typescript
import { pool } from './db';

export async function runMigrations() {
  console.log('🔄 Verificando e criando tabelas...');
  
  try {
    // Criar tabela users
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
      );
    `);
    console.log('✅ Tabela users criada/verificada');

    // Criar tabela properties
    await pool.query(`
      CREATE TABLE IF NOT EXISTS properties (
        id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
        address TEXT NOT NULL,
        type TEXT NOT NULL,
        owner TEXT NOT NULL,
        owner_document TEXT NOT NULL,
        rent_value DECIMAL(10, 2) NOT NULL,
        description TEXT
      );
    `);
    console.log('✅ Tabela properties criada/verificada');

    // Criar tabela contracts
    await pool.query(`
      CREATE TABLE IF NOT EXISTS contracts (
        id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
        property_id VARCHAR NOT NULL,
        tenant TEXT NOT NULL,
        tenant_document TEXT NOT NULL,
        tenant_email TEXT,
        tenant_phone TEXT,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        rent_value DECIMAL(10, 2) NOT NULL,
        due_day INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'active'
      );
    `);
    console.log('✅ Tabela contracts criada/verificada');

    // Criar tabela payments
    await pool.query(`
      CREATE TABLE IF NOT EXISTS payments (
        id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
        contract_id VARCHAR NOT NULL,
        reference_month TEXT NOT NULL,
        due_date TEXT NOT NULL,
        payment_date TEXT,
        value DECIMAL(10, 2) NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        payment_method TEXT,
        notes TEXT
      );
    `);
    console.log('✅ Tabela payments criada/verificada');

    // Criar tabela de sessões
    await pool.query(`
      CREATE TABLE IF NOT EXISTS user_sessions (
        sid VARCHAR NOT NULL PRIMARY KEY,
        sess JSON NOT NULL,
        expire TIMESTAMP(6) NOT NULL
      );
    `);
    console.log('✅ Tabela user_sessions criada/verificada');

    // Criar índice
    await pool.query(`
      CREATE INDEX IF NOT EXISTS IDX_session_expire ON user_sessions (expire);
    `);
    console.log('✅ Índice criado/verificado');

    console.log('🎉 Todas as tabelas foram criadas com sucesso!');
    
  } catch (error) {
    console.error('❌ Erro ao criar tabelas:', error);
    throw error;
  }
}
```

### Passo 2: Atualizar server/index.ts

Abra o arquivo `server/index.ts` e adicione estas linhas:

**NO INÍCIO DO ARQUIVO** (depois dos imports):
```typescript
import { runMigrations } from './migrate';
```

**ANTES DA LINHA `httpServer.listen(...)`**, adicione:
```typescript
// Executar migrations ao iniciar
await runMigrations();
```

### Passo 3: Fazer commit e push

```bash
git add .
git commit -m "Adicionar migrations automáticas"
git push
```

O Render vai detectar automaticamente e fazer deploy!

---

## ⏰ TEMPO ESTIMADO

- Criar arquivo: 2 min
- Editar index.ts: 1 min
- Commit e push: 1 min
- Deploy no Render: 3-5 min

**Total: 7-9 minutos**

---

## ✅ RESULTADO ESPERADO

Quando o deploy terminar, você verá nos logs do Render:

```
🔄 Verificando e criando tabelas...
✅ Tabela users criada/verificada
✅ Tabela properties criada/verificada
✅ Tabela contracts criada/verificada
✅ Tabela payments criada/verificada
✅ Tabela user_sessions criada/verificada
✅ Índice criado/verificado
🎉 Todas as tabelas foram criadas com sucesso!
```

Depois disso, o cadastro vai funcionar! 🎉

---

## 🆘 SE TIVER DÚVIDA

Me avise em qual passo está e eu te ajudo!
